package com.cleanup.todoc;

import android.view.View;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;
import androidx.test.InstrumentationRegistry;
import androidx.test.rule.ActivityTestRule;
import androidx.test.runner.AndroidJUnit4;

import com.cleanup.todoc.database.TodocDatabase;
import com.cleanup.todoc.ui.MainActivity;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.replaceText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.assertThat;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static com.cleanup.todoc.TestUtils.withRecyclerView;
import static org.hamcrest.CoreMatchers.equalTo;

/**
 * Instrumented test, which will execute on an Android device.
 *
 * @author Gaëtan HERFRAY
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
@RunWith(AndroidJUnit4.class)
public class MainActivityInstrumentedTest {
    @Rule
    public ActivityTestRule<MainActivity> rule = new ActivityTestRule<>(MainActivity.class);
    private TodocDatabase database;

    @Before
    public void initDatabase() {

        this.database = Room.inMemoryDatabaseBuilder(InstrumentationRegistry.getContext(),
                TodocDatabase.class)
                .allowMainThreadQueries()
                .build();
    }

    @After
    public void closeDatabase() {
        this.database.close();
    }

    @Test
    public void addAndRemoveTask() {
        MainActivity activity = rule.getActivity();
        TextView lblNoTask = activity.findViewById(R.id.lbl_no_task);
        RecyclerView listTasks = activity.findViewById(R.id.list_tasks);
        int count = listTasks.getAdapter().getItemCount();

        onView(withId(R.id.fab_add_task)).perform(click());
        onView(withId(R.id.txt_task_name)).perform(replaceText("Tâche example"));
        onView(withId(android.R.id.button1)).perform(click());

        // Check that lblTask is not displayed anymore
        assertThat(lblNoTask.getVisibility(), equalTo(View.GONE));
        // Check that recyclerView is displayed
        assertThat(listTasks.getVisibility(), equalTo(View.VISIBLE));
        // Check that it contains count + 1
        assertThat(listTasks.getAdapter().getItemCount(), equalTo(count +1));

        onView(withRecyclerView(R.id.list_tasks).atPositionOnView(0, R.id.img_delete))
                .perform(click());

        assertThat(listTasks.getAdapter().getItemCount(), equalTo(count));

    }

    @Test
    public void sortTasks() {
        MainActivity activity = rule.getActivity();
        RecyclerView listTasks = activity.findViewById(R.id.list_tasks);
        int count = listTasks.getAdapter().getItemCount();
        if(count > 0){
            for(int i=1;i<=count; i++ ){
                onView(withRecyclerView(R.id.list_tasks).atPositionOnView(0, R.id.img_delete))
                        .perform(click());
            }
        }

          onView(withId(R.id.fab_add_task)).perform(click());
          onView(withId(R.id.txt_task_name)).perform(replaceText("aaa Tâche example"));
          onView(withId(android.R.id.button1)).perform(click());
          onView(withId(R.id.fab_add_task)).perform(click());
          onView(withId(R.id.txt_task_name)).perform(replaceText("zzz Tâche example"));
          onView(withId(android.R.id.button1)).perform(click());
          onView(withId(R.id.fab_add_task)).perform(click());
          onView(withId(R.id.txt_task_name)).perform(replaceText("hhh Tâche example"));
          onView(withId(android.R.id.button1)).perform(click());

          // Sort alphabetical
          onView(withId(R.id.action_filter)).perform(click());
          onView(withText(R.string.sort_alphabetical)).perform(click());
          onView(withRecyclerView(R.id.list_tasks).atPositionOnView(0, R.id.lbl_task_name))
                  .check(matches(withText("aaa Tâche example")));
          onView(withRecyclerView(R.id.list_tasks).atPositionOnView(1, R.id.lbl_task_name))
                  .check(matches(withText("hhh Tâche example")));
          onView(withRecyclerView(R.id.list_tasks).atPositionOnView(2, R.id.lbl_task_name))
                  .check(matches(withText("zzz Tâche example")));

          // Sort alphabetical inverted
          onView(withId(R.id.action_filter)).perform(click());
          onView(withText(R.string.sort_alphabetical_invert)).perform(click());
          onView(withRecyclerView(R.id.list_tasks).atPositionOnView(0, R.id.lbl_task_name))
                  .check(matches(withText("zzz Tâche example")));
          onView(withRecyclerView(R.id.list_tasks).atPositionOnView(1, R.id.lbl_task_name))
                  .check(matches(withText("hhh Tâche example")));
          onView(withRecyclerView(R.id.list_tasks).atPositionOnView(2, R.id.lbl_task_name))
                  .check(matches(withText("aaa Tâche example")));

          // Sort old first
          onView(withId(R.id.action_filter)).perform(click());
          onView(withText(R.string.sort_oldest_first)).perform(click());
          onView(withRecyclerView(R.id.list_tasks).atPositionOnView(0, R.id.lbl_task_name))
                  .check(matches(withText("aaa Tâche example")));
          onView(withRecyclerView(R.id.list_tasks).atPositionOnView(1, R.id.lbl_task_name))
                  .check(matches(withText("zzz Tâche example")));
          onView(withRecyclerView(R.id.list_tasks).atPositionOnView(2, R.id.lbl_task_name))
                  .check(matches(withText("hhh Tâche example")));

          // Sort recent first
          onView(withId(R.id.action_filter)).perform(click());
          onView(withText(R.string.sort_recent_first)).perform(click());
          onView(withRecyclerView(R.id.list_tasks).atPositionOnView(0, R.id.lbl_task_name))
                  .check(matches(withText("hhh Tâche example")));
          onView(withRecyclerView(R.id.list_tasks).atPositionOnView(1, R.id.lbl_task_name))
                  .check(matches(withText("zzz Tâche example")));
          onView(withRecyclerView(R.id.list_tasks).atPositionOnView(2, R.id.lbl_task_name))
                  .check(matches(withText("aaa Tâche example")));


    }
}
